var DSMath = artifacts.require("./DSMath.sol");
var GlobalOpt = artifacts.require("./GlobalOpt.sol");

module.exports = function(deployer) {
  deployer.deploy(DSMath);
  deployer.link(DSMath, GlobalOpt);
  deployer.deploy(GlobalOpt);
  //deployer.deploy(Coordinator, "0x627306090abab3a6e1400e9345bc60c78a8bef57", "0x627306090abab3a6e1400e9345bc60c78a8bef57");
};
