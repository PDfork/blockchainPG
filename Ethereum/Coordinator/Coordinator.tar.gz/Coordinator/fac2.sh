#!/bin/bash
geth --identity "Fac2" --rpc --rpcport "9545" --rpccorsdomain "*" --datadir factory2 --port "3003" --nodiscover --rpcapi "db,eth,net,web3" --networkid 15 --nat "any"
