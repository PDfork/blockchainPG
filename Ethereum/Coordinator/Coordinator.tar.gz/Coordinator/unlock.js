web3.personal.unlockAccount(eth.coinbase, "acc1", 0)
eth.defaultAccount = eth.coinbase
miner.start()