#!/bin/bash
geth --identity "Fac1" --rpc --rpcport "8545" --rpccorsdomain "*" --datadir factory1 --port "3000" --nodiscover --rpcapi "db,eth,net,web3" --networkid 15 --nat "any"
