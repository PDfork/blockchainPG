var Coord = artifacts.require("./Coordinator.sol");

contract('Coordinator', function(accounts) {
  it("initialize", function() {
    return MetaCoin.deployed().then(function(instance) {
      return instance.init.call(accounts[0]);
    }).then(function() {
      ;
    });
  });
  it("update x", function() {
    var meta;
    var lambda;

    return Coord.deployed().then(function(instance) {
      meta = instance;
      return meta.updateX.call(1,0,accounts[0]);
    }).then(function() {
      return meta.lambda.call(accounts[0]);
    }).then(function(l) {
      lambda = l.toNumber();
    }).then(function() {
      assert.equal(l, meta.lambda.call(accounts[0]), "error");
    });
  });
});
