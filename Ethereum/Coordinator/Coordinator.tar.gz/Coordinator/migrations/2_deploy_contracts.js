var ConvertLib = artifacts.require("./ConvertLib.sol");
var MetaCoin = artifacts.require("./MetaCoin.sol");
var Coordinator = artifacts.require("./Coordinator.sol");

module.exports = function(deployer) {
  //deployer.deploy(ConvertLib);
  //deployer.link(ConvertLib, MetaCoin);
  //deployer.deploy(MetaCoin);
  deployer.deploy(Coordinator, "0x627306090abab3a6e1400e9345bc60c78a8bef57", "0x627306090abab3a6e1400e9345bc60c78a8bef57");
};
