// Import the page's CSS. Webpack will know what to do with it.
import "../stylesheets/app.css";
import "../stylesheets/dygraph.css";
import "./dygraph.js";

// Import libraries we need.
import { default as Web3} from 'web3';
import { default as contract } from 'truffle-contract'

// Import our contract artifacts and turn them into usable abstractions.
import opt_artifacts from '../../build/contracts/GlobalOpt.json'

import Dygraph from 'dygraphs';
import BigNumber from 'bignumber.js';
import assert from 'assert';
//import fs from 'fs';

var GlobalOpt = contract(opt_artifacts);
//const BigNumber = require('bignumber.js');
//const Dygraph = require('dygraphs');
//const assert = require('assert');
//const csv = require('csv');
//const fs = require('fs');

// The following code is simple to show off interacting with your contracts.
// As your needs grow you will likely need to change its form and structure.
// For application bootstrapping, check out window.addEventListener below.
var accounts;
var account;
var timerObj;
var refreshObj;
const SIGNIF_BITS = 236;
const EXP_BIAS = 262143;

var x = new BigNumber(0);
var lambda = new BigNumber(0);
var iter = 0;
var data = [];

var g;

window.App = {
  start: function() {
    var self = this;

    GlobalOpt.setProvider(web3.currentProvider);

    // Get the initial account balance so it can be displayed.
    web3.eth.getAccounts(function(err, accs) {
      if (err != null) {
        alert("There was an error fetching your accounts.");
        return;
      }

      if (accs.length == 0) {
        alert("Couldn't get any accounts! Make sure your Ethereum client is configured correctly.");
        return;
      }

      accounts = accs;
      account = accounts[0];
    });

    var meta;
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
      self.setStatus("Loading...");
      self.refreshValues();
    }).then(function() {
      return meta.getIter({from: account});
    }).then(function(it) {
      iter = it;
    }).then(function() {
      if(iter > 0) { // load values out of the local storage of the browser
        for(var i = 0; i <= iter; i++) {
          if (localStorage.getItem(i.toString()) != null) {
            var vals = localStorage.getItem(i.toString()).split(',');
            data.push([Number(i),Number(vals[0]),Number(vals[1])]);
          }
        }
      } else {
        localStorage.clear(); // clear previous saved values
        data.push([Number(iter), x.toNumber(), lambda.toNumber()]); // initialization values
        localStorage.setItem(iter.toString(),x.toString().concat(',').concat(lambda.toString()));
      }
    }).then(function() {
      g = new Dygraph(document.getElementById("div_g"), data,
        {
          legend: 'follow',
          title: 'Timeseries',
          connectSeparatedPoints: true,
          drawPoints: true,
          showRoller: false,
          //valueRange: [-2.0, 2.0],
          //dateWindow: [0,10],
          ticker: Dygraph.numericLinearTicks,
          labels: ['Iteration', 'X', 'Lambda'],
          xlabel: 'Iteration',
          ylabel: 'Values'
        });
    }).then(function() {
      g.updateOptions( { 'file': data } ); // Update of the chart
    }).then(function() {
      if(localStorage.getItem('Running') == 'true') {
        self.startOpt();
      }
      self.setStatus("");
    });
  },

  setStatus: function(message) {
    var status = document.getElementById("status");
    status.innerHTML = message;
  },
  
  BNtoB32: function(number) {
    if (number.equals(0)){
        return "0x" + "0"*64;
    }
    var signString = "0"
    if (number < 0) {
        signString = "1";
    }

    const TWO = new BigNumber(2);
    const SIGNIF_MIN = TWO.pow(SIGNIF_BITS);
    const SIGNIF_MAX = TWO.pow(SIGNIF_BITS+1).sub(1);

    //assert(SIGNIF_MIN.toString(2).length == 237);
    //assert(SIGNIF_MAX.toString(2).length == 237);
    var exponent = new BigNumber(EXP_BIAS+236);
    number = number.abs();
    while (number.gt(SIGNIF_MAX)){
        number = number.divToInt(2);
        exponent = exponent.add(1);
    }
    while (number.lt(SIGNIF_MIN)){
        number = number.mul(2);
        exponent = exponent.sub(1);
    }
    //assert(number.isInt());
    var binaryString = number.toString(2);
    binaryString = binaryString.substring(1);
    //assert(binaryString.length == 236);
    var expString = exponent.toString(2);
    expString = expString.padStart(19, "0");
    //assert(expString.length == 19);

    const final = signString + expString + binaryString;
    //assert(final.length == 256);
    const tempNumber = new BigNumber(final, 2);
    const hexEncoded = tempNumber.toString(16);
    //assert(hexEncoded.length == 64);
    return "0x"+ hexEncoded.slice(0,64);
  },
  
  B32toBN: function(bytesString) {
    bytesString = bytesString.substring(2);
    if (bytesString == '0'*64){
        return new BigNumber(0);
    }
    //assert(bytesString.length == 64);
    const TWO = new BigNumber(2);
    const SIGNIF_MIN = TWO.pow(SIGNIF_BITS);
    const SIGNIF_MAX = TWO.pow(SIGNIF_BITS+1).sub(1);
    const tempNumber = new BigNumber(bytesString, 16);
    const binaryString = tempNumber.toString(2).padStart(256,"0");
    //assert(binaryString.length == 256);
    var sign = 1;
    if (binaryString.substring(0,1) == "1"){
        sign = -1;
    }
    const expString = binaryString.substring(1,20);
    //assert(expString.length == 19);
    var exponent = new BigNumber(expString, 2);
    const mantString = binaryString.substring(20);
    //assert(mantString.length == 236);
    var mantisa = new BigNumber(mantString,2);
    mantisa = mantisa.add(SIGNIF_MIN);
    exponent = exponent.sub(EXP_BIAS+236);
    var number;
    if (exponent.toNumber() > 0){
        var number = mantisa.mul(TWO.pow(exponent)).mul(sign);
    } else if (exponent.toNumber() < 0) {
        var number = mantisa.div(TWO.pow(exponent.abs())).mul(sign);
    } else {
        var number = mantisa.mul(sign);
    }
    return number;
  },

  refreshValues: function() {
    var self = this;

    var meta;
    var elem;
    
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
    }).then(function() {
      return meta.getValue({from: account});
    }).then(function(a) {
      x = self.B32toBN(a);
    }).then(function() {
      return meta.getLambda({from: account});
    }).then(function(res) {
      lambda = self.B32toBN(res);
    }).then(function() {
      return meta.getIter({from: account});
    }).then(function(it) {
      if (it > iter) {
        data.push([it, x.toNumber(), lambda.toNumber()]);
        localStorage.setItem(it.toString(),x.toString().concat(',').concat(lambda.toString()));
        g.updateOptions( { 'file': data } ); // Update of the chart
      }
      iter = it;
    }).then(function() {
      return meta.isReady({from: account});
    }).then(function(reg) {
      elem = document.getElementById("reg");
      if(reg) {
        elem.innerHTML = "Ready!";
        elem.parentElement.style.backgroundColor = "#afa";
      } else {
        elem.innerHTML = "waiting...";
        elem.parentElement.style.backgroundColor = "#faa";
      }
    }).then(function() {
      elem = document.getElementById("state");
      if(localStorage.getItem('Running') == 'true') {
        elem.innerHTML = "running...";
        elem.parentElement.style.backgroundColor = "#afa";
      } else {
        elem.innerHTML = "stopped...";
        elem.parentElement.style.backgroundColor = "#faa";
      }
    }).then(function() {
      elem = document.getElementById("balanceA");
      elem.innerHTML = x.toExponential(3);
      elem = document.getElementById("balanceSum");
      elem.innerHTML = lambda.toExponential(3);
      elem = document.getElementById("iter");
      elem.innerHTML = iter.toString();
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error refreshing the values...");
    });
  },

  register: function() {
    var self = this;
    var meta;
    self.setStatus("Registering...");
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
    }).then(function() {
      return meta.registerMe({from: account});
    }).then(function() {
      self.refreshValues();
      self.setStatus("");
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error registering; see log.");
    });
  },
  
  startOpt: function() {
    var self = this;
    timerObj = setInterval(function() {
      self.setStatus("Updating values...");

      var meta;
      var update;
      GlobalOpt.deployed().then(function(instance) {
        meta = instance;
      }).then(function() {
        return meta.getLambda({from: account});
      }).then(function(res) {
        lambda = self.B32toBN(res);
      }).then(function() {
        return meta.getIter({from: account});
      }).then(function(it) {
        if (it > iter) {
          data.push([it, x.toNumber(), lambda.toNumber()]);
          localStorage.setItem(it.toString(),x.toString().concat(',').concat(lambda.toString()));
          g.updateOptions( { 'file': data } ); // Update of the chart
        }
        iter = Number(it);
      }).then(function() {
        update = lambda.mul(-1).div(2).add(2);
        if (iter == 0) { // clearing data for initial values
          data = [];
          data.push([iter, update.toNumber(), lambda.toNumber()]);
          localStorage.setItem(iter.toString(),update.toString().concat(',').concat(lambda.toString()));
          g.updateOptions( { 'file': data } ); // Update of the chart
        }
        update = self.BNtoB32(update);
      }).then(function() {
        return meta.setValue(update, {from: account, gas: 500000});
      }).then(function() {
        self.setStatus("");
      }).catch(function(e) {
        console.log(e);
        self.setStatus("Error updating; see log.");
      });
    },13000);

    refreshObj = setInterval(function() {
      self.refreshValues();
    },1000);

    localStorage.setItem('Running','true');
    self.refreshValues();
  },
  
  stopOpt: function() {
    var self = this;
    clearInterval(timerObj);
    clearInterval(refreshObj);
    localStorage.setItem('Running','false');
    self.refreshValues();
  },

  resetOpt: function() {
    var self = this;
    clearInterval(timerObj);
    clearInterval(refreshObj);
    localStorage.setItem('Running','false');
    self.refreshValues();
    var meta;
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
      self.setStatus("Resetting...");
    }).then(function() {
      return meta.resetAll({from: account, gas: 500000});
    }).then(function() {
      self.refreshValues();
      self.setStatus("Reset complete!");
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error resetting; see log.");
    });
  },

  convertArrayOfObjectsToCSV : function(args) {  
    var result, ctr, keys, columnDelimiter, lineDelimiter, csvdata;

    csvdata = args.csvdata || null;
    if (csvdata == null || !csvdata.length) {
        return null;
    }

    columnDelimiter = args.columnDelimiter || ',';
    lineDelimiter = args.lineDelimiter || '\n';

    keys = Object.keys(csvdata[0]);

    result = '';
    result += keys.join(columnDelimiter);
    result += lineDelimiter;

    csvdata.forEach(function(item) {
        ctr = 0;
        keys.forEach(function(key) {
            if (ctr > 0) result += columnDelimiter;

            result += item[key];
            ctr++;
        });
        result += lineDelimiter;
    });
    return result;
  },

  downloadCSV: function() {  
    var csvdata, filename, link;
    var self = this;
    var csv = this.convertArrayOfObjectsToCSV({
        csvdata: data
    });
    if (csv == null) return;

    filename = data.filename || 'export_node1.csv';

    if (!csv.match(/^data:text\/csv/i)) {
        csv = 'data:text/csv;charset=utf-8,' + csv;
    }
    csvdata = encodeURI(csv);

    link = document.createElement('a');
    link.setAttribute('href', csvdata);
    link.setAttribute('download', filename);
    link.click();
  }
};

window.addEventListener('load', function() {
  // Checking if Web3 has been injected by the browser (Mist/MetaMask)
  if (typeof web3 !== 'undefined') {
    console.warn("Using web3 detected from external source. If you find that your accounts don't appear or you have 0 MetaCoin, ensure you've configured that source properly. If using MetaMask, see the following link. Feel free to delete this warning. :) http://truffleframework.com/tutorials/truffle-and-metamask")
    // Use Mist/MetaMask's provider
    window.web3 = new Web3(web3.currentProvider);
    BigNumber = web3.BigNumber;
  } else {
    console.warn("No web3 detected. Falling back to http://127.0.0.1:7545. You should remove this fallback when you deploy live, as it's inherently insecure. Consider switching to Metamask for development. More info here: http://truffleframework.com/tutorials/truffle-and-metamask");
    // fallback - use your fallback strategy (local node / hosted node + in-dapp id mgmt / fail)
    window.web3 = new Web3(new Web3.providers.HttpProvider("http://127.0.0.1:7545"));
  }

  App.start();
});
