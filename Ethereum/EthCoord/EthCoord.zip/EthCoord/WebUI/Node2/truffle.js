// Allows us to use ES6 in our migrations and tests.
require('babel-register')
var Web3 = require('web3');
var prov = new Web3.providers.HttpProvider("http://127.0.0.1:3002");

module.exports = {
  networks: {
    development: {
      host: 'localhost',
      port: 8545,
      network_id: '*' // Match any network id
    },
    node1: {
      host: 'localhost',
      port: 7545,
      network_id: '1337' // any network associated with your node
    },
    node2: {
      host: 'localhost',
      port: 8545,
      network_id: '1337' // any network associated with your node
    },
    node3: {
      host: 'localhost',
      port: 9545,
      network_id: '1337' // any network associated with your node
    }
  }
}
