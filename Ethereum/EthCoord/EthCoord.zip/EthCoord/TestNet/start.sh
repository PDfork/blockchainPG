#!/bin/bash
xterm -title "Node3" -e "geth --identity 'Node3' --datadir 'node3' --port 3003 --networkid 1337 --nodiscover --rpc --rpcport 9545 --rpccorsdomain '*' --rpcapi 'db,eth,net,web3' --unlock 0x2538f26b169a3d1d7fbb9872d99822fa666912f0 --mine console test.json" &
sleep 1s
xterm -title "Node2" -e "geth --identity 'Node2' --datadir 'node2' --port 3002 --networkid 1337 --nodiscover --rpc --rpcport 8545 --rpccorsdomain '*' --rpcapi 'db,eth,net,web3' --unlock 0x0f2489e507b42e36a7c23239a8625811214eb1ac --mine console test.json" &
sleep 1s
xterm -title "Node1" -e "geth --identity 'Node1' --datadir 'node1' --port 3001 --networkid 1337 --nodiscover --rpc --rpcport 7545 --rpccorsdomain '*' --rpcapi 'db,eth,net,web3' --unlock 0x9cc73b98473d4aba3d1ab6a8533e805349d06764 --mine console test.json" &
