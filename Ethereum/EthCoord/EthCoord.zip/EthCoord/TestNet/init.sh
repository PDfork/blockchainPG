#!/bin/bash
geth --identity "Node1" --rpc --rpcport "7545" --rpccorsdomain "*" --datadir node1 --port "3001" --nodiscover --rpcapi "db,eth,net,web3" --networkid 1337 init test.json

geth --identity "Node2" --rpc --rpcport "8545" --rpccorsdomain "*" --datadir node2 --port "3002" --nodiscover --rpcapi "db,eth,net,web3" --networkid 1337 init test.json

geth --identity "Node3" --rpc --rpcport "9545" --rpccorsdomain "*" --datadir node3 --port "3003" --nodiscover --rpcapi "db,eth,net,web3" --networkid 1337 init test.json
