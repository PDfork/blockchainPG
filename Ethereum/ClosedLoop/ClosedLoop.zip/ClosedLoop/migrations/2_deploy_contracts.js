var FloatMath = artifacts.require("./FloatMath.sol");
var GlobalOpt = artifacts.require("./GlobalOpt.sol");

module.exports = function(deployer) {
  deployer.deploy(FloatMath);
  deployer.link(FloatMath, GlobalOpt);
  deployer.deploy(GlobalOpt);
};
