// Import the page's CSS. Webpack will know what to do with it.
import '../stylesheets/app.css';

// Import libraries we need.
import { default as Web3} from 'web3';
import { default as contract } from 'truffle-contract'

// Import our contract artifacts and turn them into usable abstractions.
import opt_artifacts from '../../build/contracts/GlobalOpt.json'

// MetaCoin is our usable abstraction, which we'll use through the code below.
//var MetaCoin = contract(metacoin_artifacts);
var BigNumber = require('bignumber.js');
var GlobalOpt = contract(opt_artifacts);

// The following code is simple to show off interacting with your contracts.
// As your needs grow you will likely need to change its form and structure.
// For application bootstrapping, check out window.addEventListener below.
var accounts;
var account;

const SIGNIF_BITS = 236;
const EXP_BIAS = 262143;

// Timers object
var timerObj;

var lambda;

window.App = {
  start: function() {
    var self = this;

    GlobalOpt.setProvider(web3.currentProvider);

    // Get the initial account balance so it can be displayed.
    web3.eth.getAccounts(function(err, accs) {
      if (err != null) {
        alert("There was an error fetching your accounts.");
        return;
      }

      if (accs.length == 0) {
        alert("Couldn't get any accounts! Make sure your Ethereum client is configured correctly.");
        return;
      }

      accounts = accs;
      account = accounts[0];

      self.refreshValues();
    });
  },

  setStatus: function(message) {
    var status = document.getElementById("status");
    status.innerHTML = message;
  },
  
  BNtoB32: function(number) {
    if (number.equals(0)){
        return "0x" + "0"*64;
    }
    var signString = "0"
    if (number < 0) {
        signString = "1";
    }

    const TWO = new BigNumber(2);
    const SIGNIF_MIN = TWO.pow(SIGNIF_BITS);
    const SIGNIF_MAX = TWO.pow(SIGNIF_BITS+1).sub(1);

    //assert(SIGNIF_MIN.toString(2).length == 237);
    //assert(SIGNIF_MAX.toString(2).length == 237);
    var exponent = new BigNumber(EXP_BIAS+236);
    number = number.abs();
    while (number.gt(SIGNIF_MAX)){
        number = number.divToInt(2);
        exponent = exponent.add(1);
    }
    while (number.lt(SIGNIF_MIN)){
        number = number.mul(2);
        exponent = exponent.sub(1);
    }
    //assert(number.isInt());
    var binaryString = number.toString(2);
    binaryString = binaryString.substring(1);
    //assert(binaryString.length == 236);
    var expString = exponent.toString(2);
    expString = expString.padStart(19, "0");
    //assert(expString.length == 19);

    const final = signString + expString + binaryString;
    //assert(final.length == 256);
    const tempNumber = new BigNumber(final, 2);
    const hexEncoded = tempNumber.toString(16);
    //assert(hexEncoded.length == 64);
    return "0x"+ hexEncoded.slice(0,64);
  },
  
  B32toBN: function(bytesString) {
    bytesString = bytesString.substring(2);
    if (bytesString == '0'*64){
        return new BigNumber(0);
    }
    //assert(bytesString.length == 64);
    const TWO = new BigNumber(2);
    const SIGNIF_MIN = TWO.pow(SIGNIF_BITS);
    const SIGNIF_MAX = TWO.pow(SIGNIF_BITS+1).sub(1);
    const tempNumber = new BigNumber(bytesString, 16);
    const binaryString = tempNumber.toString(2).padStart(256,"0");
    //assert(binaryString.length == 256);
    var sign = 1;
    if (binaryString.substring(0,1) == "1"){
        sign = -1;
    }
    const expString = binaryString.substring(1,20);
    //assert(expString.length == 19);
    var exponent = new BigNumber(expString, 2);
    const mantString = binaryString.substring(20);
    //assert(mantString.length == 236);
    var mantisa = new BigNumber(mantString,2);
    mantisa = mantisa.add(SIGNIF_MIN);
    exponent = exponent.sub(EXP_BIAS+236);
    var number;
    if (exponent.toNumber() > 0){
        var number = mantisa.mul(TWO.pow(exponent)).mul(sign);
    } else if (exponent.toNumber() < 0) {
        var number = mantisa.div(TWO.pow(exponent.abs())).mul(sign);
    } else {
        var number = mantisa.mul(sign);
    }
    return number;
  },
  
  refreshValues: function() {
    var self = this;

    var meta;
    var elem;
    var num1;
    var num2;
    var num3;
    var numL;
    
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
    }).then(function() {
      return meta.getValue(0,{from: account});
      //return self.BNtoB32(BigNumber("51.648"))
    }).then(function(a) {
      num1 = self.B32toBN(a);
      //num1 = a;
    }).then(function() {
      return meta.getValue(1,{from: account});
      //return self.BNtoB32(BigNumber("51.648"))
    }).then(function(a) {
      num2 = self.B32toBN(a);
      //num1 = a;
    }).then(function() {
      return meta.getValue(2,{from: account});
      //return self.BNtoB32(BigNumber("51.648"))
    }).then(function(a) {
      num3 = self.B32toBN(a);
      //num1 = a;
    }).then(function() {
      return meta.getLambda({from: account});
      //return self.BNtoB32(BigNumber(51.648))
    }).then(function(res) {
      numL = self.B32toBN(res);
      lambda = numL;
      //numL = res;
    }).then(function() {
      return meta.isReady({from: account});
    }).then(function(reg) {
      elem = document.getElementById("reg");
      elem.innerHTML = reg;
    }).then(function() {
      return meta.getIter({from: account});
    }).then(function(iter) {
      elem = document.getElementById("iter");
      elem.innerHTML = iter;
    }).then(function() {
      elem = document.getElementById("balanceA");
      elem.innerHTML = num1.toExponential(9);
      //elem.innerHTML = num1;
      elem = document.getElementById("balanceB");
      elem.innerHTML = num2.toExponential(9);
      //elem.innerHTML = num2;
      elem = document.getElementById("balanceC");
      elem.innerHTML = num3.toExponential(9);
      //elem.innerHTML = num3;
      elem = document.getElementById("balanceSum");
      elem.innerHTML = numL.toExponential(9);
      //elem.innerHTML = numL;
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error refreshing the values...");
    });
  },

  reg1: function() {
    var self = this;
    self.setStatus("Register node 1... (please wait)");

    var meta;
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
    }).then(function() {
      return meta.registerMe(0, {from: account, gas: 1000000});
    }).then(function() {
      self.setStatus("Registry complete!");
      self.refreshValues();
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error registering; see log.");
    });
  },

  reg2: function() {
    var self = this;
    self.setStatus("Register node 2... (please wait)");

    var meta;
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
    }).then(function() {
      return meta.registerMe(1, {from: account, gas: 1000000});
    }).then(function() {
      self.setStatus("Registry complete!");
      self.refreshValues();
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error registering; see log.");
    });
  },

  reg3: function() {
    var self = this;
    self.setStatus("Register node 3... (please wait)");

    var meta;
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
    }).then(function() {
      return meta.registerMe(2, {from: account, gas: 1000000});
    }).then(function() {
      self.setStatus("Registry complete!");
      self.refreshValues();
    }).catch(function(e) {
      console.log(e);
      self.setStatus("Error registering; see log.");
    });
  },
  
  startOpt: function() {
    var self = this;
    timerObj = setInterval(function() {
      self.setStatus("Updating values... (please wait)");

      var update1 = lambda.mul(-1).div(2).add(2);
      update1 = self.BNtoB32(update1);
      var update2 = lambda.mul(-1).div(2).sub(2.5);
      update2 = self.BNtoB32(update2);
      var update3 = lambda.mul(-1).div(2);
      update3 = self.BNtoB32(update3);

      var meta;
      GlobalOpt.deployed().then(function(instance) {
        meta = instance;
      }).then(function() {
        return meta.setValue(0, update1, {from: account, gas: 1000000});
      }).then(function() {
        return meta.setValue(1, update2, {from: account, gas: 1000000});
      }).then(function() {
        return meta.setValue(2, update3, {from: account, gas: 1000000});
      }).then(function() {
        self.setStatus("Update complete!");
        self.refreshValues();
      }).catch(function(e) {
        console.log(e);
        self.setStatus("Error updating the values; see log.");
      });
    },3000)
  },
  
  stopOpt: function() {
    clearInterval(timerObj)
    this.setStatus("Updating stopped!");
  }
};

window.addEventListener('load', function() {
  // Checking if Web3 has been injected by the browser (Mist/MetaMask)
  if (typeof web3 !== 'undefined') {
    console.warn("Using web3 detected from external source. If you find that your accounts don't appear or you have 0 MetaCoin, ensure you've configured that source properly. If using MetaMask, see the following link. Feel free to delete this warning. :) http://truffleframework.com/tutorials/truffle-and-metamask")
    // Use Mist/MetaMask's provider
    window.web3 = new Web3(web3.currentProvider);
  } else {
    console.warn("No web3 detected. Falling back to http://127.0.0.1:9545. You should remove this fallback when you deploy live, as it's inherently insecure. Consider switching to Metamask for development. More info here: http://truffleframework.com/tutorials/truffle-and-metamask");
    // fallback - use your fallback strategy (local node / hosted node + in-dapp id mgmt / fail)
    window.web3 = new Web3(new Web3.providers.HttpProvider("http://127.0.0.1:9545"));
  }

  App.start();
});

function opt() {
  var timer = setInterval(function() {
    var meta;
    GlobalOpt.deployed().then(function(instance) {
      meta = instance;
    }).then(function() {
      return meta.updateLambda({from: account});
    }).then(function() {
      return meta.getLambda({from: account});
    }).catch(function(e) {
      console.log(e);
    });
  },500);
}